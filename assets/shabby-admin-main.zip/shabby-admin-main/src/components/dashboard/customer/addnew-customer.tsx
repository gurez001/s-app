import * as React from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { FormControl, FormHelperText, InputLabel, MenuItem, OutlinedInput, Select, Typography } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Slide from '@mui/material/Slide';
import { TransitionProps } from '@mui/material/transitions';
import { Box, fontSize, padding, Stack } from '@mui/system';
import { Controller, useForm } from 'react-hook-form';
import { z as zod } from 'zod';

const schema = zod.object({
  phone: zod
    .string()
    .min(1, { message: 'phone is required' })
    .regex(/^[0-9]{10}$/, { message: 'Invalid phone number' }),
  branch: zod.string().min(1, { message: 'Branch is required' }),
});

type Values = zod.infer<typeof schema>;

interface AddNewCustomerProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement<any, any>;
  },
  ref: React.Ref<unknown>
) {
  return <Slide direction="left" ref={ref} {...props} />;
});

const Add_new_customer: React.FC<AddNewCustomerProps> = ({ open, setOpen }) => {
  const {
    control,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm<Values>({ resolver: zodResolver(schema) });

  const handleClose = () => {
    setOpen(false);
  };

  const onSubmit = (data: Values) => {
    console.log('Form Data:', data);
    // Handle form submission logic here
    handleClose();
  };

  return (
    <Box>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        className="add-cus"
        aria-describedby="alert-dialog-slide-description"
        PaperProps={{
          style: {
            justifyContent: 'flex-end',
            minWidth: '350px', // Make the dialog full width
            margin: '0px',
          },
        }}
      >
        <DialogTitle>
          <Stack spacing={1}>
            <Typography variant="h4">Add new Customer</Typography>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            <Stack spacing={45}>
              <Controller
                control={control}
                name="phone"
                render={({ field }) => (
                  <FormControl
                    sx={{
                      marginTop: '13px', // Adjust the font size here
                    }}
                    error={Boolean(errors.phone)}
                  >
                    <InputLabel
                      sx={{
                        top: '-6px',
                        fontSize: '13px', // Adjust the font size here
                      }}
                    >
                      phone address
                    </InputLabel>
                    <OutlinedInput
                      inputProps={{
                        style: {
                          padding: '10px', // Adjust the padding here
                          fontSize: '12px', // Adjust the font size here if needed
                        },
                      }}
                      {...field}
                      label="phone address"
                      type="phone"
                    />
                    {errors.phone ? <FormHelperText>{errors.phone.message}</FormHelperText> : null}
                  </FormControl>
                )}
              />
            </Stack>
            <Controller
              control={control}
              name="branch"
              render={({ field }) => (
                <FormControl style={{ marginTop: '10px', width: '100%' }} error={Boolean(errors.branch)}>
                  <InputLabel
                    sx={{
                      fontSize: '13px', // Adjust the font size here
                    }}
                  >
                    Branch
                  </InputLabel>
                  <Select
                    style={{
                      top: '6px',
                      padding: '0px', // Adjust the padding here
                      fontSize: '12px', // Adjust the font size here if needed
                    }}
                    {...field}
                    label="Branch"
                    inputProps={{ sx: { padding: '10px', fontSize: '14px' } }}
                    MenuProps={{
                      PaperProps: {
                        sx: {
                          fontSize: '14px',
                          maxHeight: 200, // Example: Limit the height of the menu
                          overflow: 'auto', // Enable scrolling if needed
                        },
                      },
                    }}
                  >
                    <MenuItem value="">Select a branch</MenuItem>
                    <MenuItem value="branch1">Branch 1</MenuItem>
                    <MenuItem value="branch2">Branch 2</MenuItem>
                    <MenuItem value="branch3">Branch 3</MenuItem>
                    {/* Add more options as needed */}
                  </Select>
                  {errors.branch && <FormHelperText>{errors.branch.message}</FormHelperText>}
                </FormControl>
              )}
            />
            <Button
              // disabled={isPending}
              sx={{ padding: '5px 10px', marginTop:'15px', fontSize: '14px' }}
              type="submit"
              variant="contained"
            >
              Add New
            </Button>
          </form>
        </DialogContent>
        <DialogActions></DialogActions>
      </Dialog>
    </Box>
  );
};
export default Add_new_customer;
